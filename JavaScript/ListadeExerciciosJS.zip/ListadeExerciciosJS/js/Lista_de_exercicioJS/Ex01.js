var c, f, k

c=prompt("Digite o valor da temperatura em Celsius: ")

k=parseFloat(c) + 273.15
alert("O valor da temperatura em Kelvin é: "+k+"K")


f=(parseFloat(c)*9/5) + 32 
alert("O valor da temperatura em Fahrenheit é: "+f+"°F") 