var n, cont, 




n=prompt("Digite um número para gerar o fatorial: ")
 

for(f=1; n>1; n=n-1){
    
    f=parseInt(f)*parseInt(n)
    ///f=f*n
    
}
alert("O fatorial do número é "+n+"! = " +f)

   